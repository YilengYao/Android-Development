package ca.yiyao.countingrooms;

import java.util.Random;

/**
 * Created by user on 6/29/17.
 */
public class CreateMap
{
    private static int width;
    private static int height;
    private static int size;
    private static double picker;

    public CreateMap()
    {
        Random rand = new Random();
        this.width = rand.nextInt(11);
        this.height = rand.nextInt(11);
        this.size = rand.nextInt(Math.min(this.width, this.height));
        this.picker = Math.random();
    }

    public Location[] getMap()
    {
        if(this.picker < 0.5)
        {
            return buildBorder();
        } else {
            return concatArray(buildBorder(), buildL(this.size, this.width, this.height));
        }

    }

    public Location[] buildL(int size, int borderWidth, int borderHeight)
    {
        Location[] L = new Location[size*size];
        int k =0;
        for(int i = borderWidth - size; i < borderWidth; i++)
        {
            for(int j = 0; j < size; j++)
            {
                L[k] = new Location(i, j);
                k++;
            }
        }
        return L;
    }

    public Location[] buildBorder(){
        Location[] northBorder = createHorizontalBorder(this.width, -1);
        Location[] southBorder = createHorizontalBorder(this.width, this.height);
        Location[] eastBorder = createVerticalBorder(this.height, this.width);
        Location[] westBorder = createVerticalBorder(this.height, -1);
        Location[] verticalBorder = concatArray(eastBorder, westBorder);
        Location[] horizontalBorder = concatArray(northBorder, southBorder);
        return concatArray(verticalBorder, horizontalBorder);
    }

    public Location[] createVerticalBorder(int n, int position)
    {
        Location[] border = new Location[n];
        for(int i = 0; i < n; i++)
        {
            border[i] = new Location(position, i);
        }
        return border;
    }

    public Location[] createHorizontalBorder(int n, int position)
    {
        Location[] border = new Location[n];
        for(int i = 0; i < n; i++)
        {
            border[i] = new Location(i, position);
        }
        return border;
    }

    public Location[] concatArray(Location[] j, Location[] k)
    {
        int n = j.length +k.length;
        Location[] concatArray = new Location[n];
        for(int i = 0; i < n; i++)
        {
            if(i < j.length)
            {
                concatArray[i] = j[i];
            } else
            {
                concatArray[i] = k[i - j.length];
            }
        }
        return concatArray;
    }
}
