package ca.yiyao.countingrooms;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.io.PrintStream;
import java.util.Scanner;

public class CountingRooms extends AppCompatActivity
{
    private Counter roomCounter;
    private Location robot;
    private CreateMap map;
    private Location[] forbidden;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counting_rooms);
        this.roomCounter = new Counter();
        this.robot = new Location();
        this.map = new CreateMap();
        this.forbidden = this.map.getMap();
    }
    //private Location[] forbidden = this.map.getMap();
//private Location[] forbidden = new Location[0];

    public void northClicked(View view)
    {
        if(this.robot.canGoNorth(this.forbidden))
        {
            this.roomCounter.northCounter();
            this.robot.goNorth();
        }
        this.returnCount();
        this.changeColor();
    }

    public void southClicked(View view)
    {
        if(this.robot.canGoSouth(this.forbidden))
        {
            this.roomCounter.southCounter();
            this.robot.goSouth();
        }
        this.returnCount();
        this.changeColor();
    }

    public void eastClicked(View view)
    {
        if(robot.canGoEast(this.forbidden))
        {
            this.roomCounter.eastCounter();
            this.robot.goEast();
        }
        this.returnCount();
        this.changeColor();
    }

    public void westClicked(View view)
    {
        if(robot.canGoWest(this.forbidden))
        {
            this.roomCounter.westCounter();
            this.robot.goWest();
        }
        this.returnCount();
        this.changeColor();
    }

    public void returnCount()
    {
        String answer = this.robot.toString();
        View clickCounterView = findViewById(R.id.clickCounter);
        TextView clickCounterText = (TextView) clickCounterView;
        clickCounterText.setText(answer);
    }

    public void changeColor()
    {
        TextView northButton = (TextView) findViewById(R.id.northButton);
        TextView southButton = (TextView) findViewById(R.id.southButton);
        TextView eastButton = (TextView) findViewById(R.id.eastButton);
        TextView westButton = (TextView) findViewById(R.id.westButton);

        if(this.robot.canGoNorth(this.forbidden))
        {
            northButton.setBackgroundColor(Color.GREEN);
        } else {
            northButton.setBackgroundColor(Color.RED);
        }

        if(this.robot.canGoSouth(this.forbidden))
        {
            southButton.setBackgroundColor(Color.GREEN);
        } else {
            southButton.setBackgroundColor(Color.RED);
        }

        if(this.robot.canGoEast(this.forbidden))
        {
            eastButton.setBackgroundColor(Color.GREEN);
        } else {
            eastButton.setBackgroundColor(Color.RED);
        }

        if(this.robot.canGoWest(this.forbidden))
        {
            westButton.setBackgroundColor(Color.GREEN);
        } else {
            westButton.setBackgroundColor(Color.RED);
        }

    }


}
