package ca.yiyao.countingrooms;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Created by user on 7/2/17.
 */
public class test
{
    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        PrintStream output = System.out;

        CreateMap map = new CreateMap();
        Location[] fs = map.getMap();
        String length = String.format("%s", fs.length);
        output.println(length);


    }
}
