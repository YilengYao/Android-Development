package ca.roumani.bmi;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Created by user on 6/20/17.
 */
public class BMIModel
{
    private double weight;
    private double height;

    public BMIModel(String w, String h)
    {
        this.weight = Double.parseDouble(w);
        this.height = Double.parseDouble(h);
    }

    public String getBMI()
    {
        double BMIIndex = this.weight / (this.height*this.height);
        String result = String.format("%.1f", BMIIndex);
        return result;
    }

    public String getWeightInPound()
    {
        double weightPound = this.weight*2.20462;
        String result = String.format("%.0f", weightPound);
        return result;
    }

    public static void main(String[] args)
    {
        Scanner input = new Scanner(System.in);
        PrintStream output = System.out;

        BMIModel model = new BMIModel("100", "1.8");
        String answer = "Your weight in kilogram is " + model.getBMI();
        output.println(answer);
    }


}
