package ca.yiyao.countingrooms;

/**
 * Created by user on 6/29/17.
 */
public class Location
{
    private int locationX;
    private int locationY;
    public Location()
    {
        this.locationX = 0;
        this.locationY = 0;
    }

    public Location(int x, int y)
    {
        this.locationX = x;
        this.locationY = y;
    }

    public int getX()
    {
        return this.locationX;
    }

    public int getY()
    {
        return this.locationY;
    }

    public Location east()
    {
        Location east = new Location(this.getX() + 1, this.getY());
        return east;
    }

    public Location north()
    {
        Location north = new Location(this.getX(), this.getY() - 1);
        return north;
    }

    public Location south()
    {
        Location south = new Location(this.getX(), this.getY() + 1);
        return south;
    }

    public Location west()
    {
        Location west = new Location(this.getX() - 1, this.getY());
        return west;
    }

    public Location goNorth()
    {
        this.locationY--;
        return this;
    }

    public Location goSouth()
    {
        this.locationY++;
        return this;
    }

    public Location goEast()
    {
        this.locationX++;
        return this;
    }

    public Location goWest()
    {
        this.locationX--;
        return this;
    }

    public String toString()
    {
        String x = String.format("%s", this.locationX);
        String y = String.format("%s", this.locationY);
        return "(" + x + "," + y + ")";
    }

    public boolean canGoEast(Location[] a)
    {
        for(int i = 0; i < a.length; i++)
        {
            if((this.east().getX() == a[i].getX())&&(this.east().getY() == a[i].getY()))
            {
                return false;
            }
        }
        return true;
    }

    public boolean canGoNorth(Location[] a)
    {
        for(int i = 0; i < a.length; i++)
        {
            if((this.north().getX() == a[i].getX())&&(this.north().getY() == a[i].getY()))
            {
                return false;
            }
        }
        return true;
    }

    public boolean canGoSouth(Location[] a)
    {
        for(int i = 0; i < a.length; i++)
        {
            if((this.south().getX() == a[i].getX())&&(this.south().getY() == a[i].getY()))
            {
                return false;
            }
        }
        return true;
    }

    public boolean canGoWest(Location[] a)
    {
        for(int i = 0; i < a.length; i++)
        {
            if((this.west().getX() == a[i].getX())&&(this.west().getY() == a[i].getY()))
            {
                return false;
            }
        }
        return true;
    }
}
