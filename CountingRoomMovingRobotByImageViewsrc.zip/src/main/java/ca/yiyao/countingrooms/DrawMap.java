package ca.yiyao.countingrooms;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.BitmapDrawable;
import android.view.View;
import android.widget.ImageView;

/**
 * Created by user on 7/7/17.
 */
public class DrawMap
{
    private static int gridWidth, gridHeight, layoutSize;
    public static int roomSize, margin, x_correction;
    public static Canvas canvas;
    public static Bitmap bitmap;
    public static BitmapDrawable mapGrid;


    Location[] blockedRooms;
    Paint blue_paintbrush_fill, red_paintbrush_fill, yellow_paintbrush_fill, green_paintbrush_fill, black_paintbrush_fill;

    public DrawMap(int gridWidth, int gridHeight, int layoutSize, Location[] blockedRooms) {
        this.gridWidth = gridWidth;
        this.gridHeight = gridHeight;
        this.layoutSize = layoutSize;
        this.blockedRooms = blockedRooms;
        if(this.gridWidth > this.gridHeight){
            this.x_correction = ((this.gridWidth-this.gridHeight)*this.roomSize)/2;
        } else {
            this.x_correction = 0;
        }
        bitmap = Bitmap.createBitmap(layoutSize,layoutSize, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);

        drawGrid();

    }




    public void drawGrid() {

        //initializes painting objects
        blue_paintbrush_fill = new Paint();
        blue_paintbrush_fill.setColor(Color.BLUE);
        blue_paintbrush_fill.setStyle(Paint.Style.FILL);

        red_paintbrush_fill = new Paint();
        red_paintbrush_fill.setColor(Color.RED);
        red_paintbrush_fill.setStyle(Paint.Style.FILL);

        yellow_paintbrush_fill = new Paint();
        yellow_paintbrush_fill.setColor(Color.YELLOW);
        yellow_paintbrush_fill.setStyle(Paint.Style.FILL);

        green_paintbrush_fill = new Paint();
        green_paintbrush_fill.setColor(Color.GREEN);
        green_paintbrush_fill.setStyle(Paint.Style.FILL);

        black_paintbrush_fill = new Paint();
        black_paintbrush_fill.setColor(Color.BLACK);
        black_paintbrush_fill.setStyle(Paint.Style.FILL);

        this.roomSize = this.layoutSize / Math.max(this.gridWidth, this.gridHeight);
        this.margin = this.roomSize/5;

        buildBlockedCells();
        buildNorthWall();
        buildSouthWall();
        buildEastWall();
        buildWestWall();

        mapGrid = new BitmapDrawable(bitmap);
    }

    public void buildBlockedCells(){

        for(int i = 0 ;i < this.blockedRooms.length; i++){
            int xx = this.blockedRooms[i].getX();
            int yy = this.blockedRooms[i].getY();
            int[] x = {xx*this.roomSize + this.x_correction,(xx+1)*this.roomSize + this.x_correction,(xx+1)*this.roomSize + this.x_correction,xx*this.roomSize + this.x_correction};
            int[] y = {yy*this.roomSize,yy*this.roomSize, (yy+1)*this.roomSize, (yy+1)*this.roomSize};
            canvas.drawPath(trapazoid(x,y), black_paintbrush_fill);
        }
    }

    public void buildNorthWall(){
        for(int i = 0; i < this.gridHeight; i ++){
            for(int j = 0; j < this.gridWidth; j++){
                int[] x = {i*this.roomSize + this.x_correction, (i+1)*this.roomSize + this.x_correction, (i+1)*this.roomSize - this.margin + this.x_correction, (i)*this.roomSize+this.margin + this.x_correction};
                int[] y = {j*this.roomSize, j*this.roomSize, j*this.roomSize + this.margin, j*this.roomSize+ this.margin};
                canvas.drawPath(trapazoid(x,y), blue_paintbrush_fill);
            }
        }
    }

    public void buildSouthWall(){
        for(int i = 0; i < this.gridHeight; i ++){
            for(int j = 0; j < this.gridWidth; j++){
                int[] x = {i*this.roomSize + this.margin + this.x_correction, (i+1)*this.roomSize - this.margin + this.x_correction, (i+1)*this.roomSize + this.x_correction, (i)*this.roomSize + this.x_correction};
                int[] y = {(j+1)*this.roomSize - this.margin, (j+1)*this.roomSize - margin, (j+1)*this.roomSize, (j+1)*this.roomSize};
                canvas.drawPath(trapazoid(x,y), red_paintbrush_fill);
            }
        }
    }

    public void buildEastWall(){
        for(int i = 0; i < this.gridHeight; i ++){
            for(int j = 0; j < this.gridWidth; j++){
                int[] x = {(i+1)*this.roomSize - this.margin + this.x_correction, (i+1)*this.roomSize + this.x_correction, (i+1)*this.roomSize + this.x_correction, (i+1)*this.roomSize - this.margin + this.x_correction};
                int[] y = {(j)*this.roomSize + this.margin, (j)*this.roomSize, (j+1)*this.roomSize, (j+1)*this.roomSize - this.margin};
                canvas.drawPath(trapazoid(x,y), yellow_paintbrush_fill);
            }
        }
    }

    public void buildWestWall(){
        for(int i = 0; i < this.gridHeight; i ++){
            for(int j = 0; j < this.gridWidth; j++){
                int[] x = {i*this.roomSize + this.x_correction, i*this.roomSize + this.margin + this.x_correction, i*this.roomSize + this.margin + this.x_correction, i*this.roomSize + this.x_correction};
                int[] y = {j*this.roomSize, j*this.roomSize + this.margin, (j+1)*this.roomSize - this.margin, (j+1)*this.roomSize};
                canvas.drawPath(trapazoid(x,y), green_paintbrush_fill);
            }
        }
    }

    public Path trapazoid(int[] x, int[] y){
        Path trapazoid = new Path();
        trapazoid.moveTo(x[0],y[0]);
        for(int i =0; i < 3; i++){
            trapazoid.lineTo(x[i+1], y[i+1]);
        }
        trapazoid.lineTo(x[0], y[0]);
        return trapazoid;
    }
}
