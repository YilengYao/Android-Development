package ca.yiyao.countingrooms;

import java.util.Random;

/**
 * Created by user on 6/29/17.
 */
public class CreateMap
{
    public static int width;
    public static int height;
    private static int size;
    private static double picker;
    public Location[] blockedRooms;

    public CreateMap()
    {
        Random rand = new Random();
        this.width = rand.nextInt(11)+1;
        this.height = rand.nextInt(11)+1;
        this.picker = Math.random();
    }

    public Location[] getMap()
    {
        if(this.picker < 0.1)
        {
            this.blockedRooms = new Location[0];
            return buildBorder();
        } else {
            this.blockedRooms = buildL(this.width, this.height);
            return concatArray(buildBorder(), this.blockedRooms);
        }

    }

    public Location[] buildL(int borderWidth, int borderHeight)
    {
        Random rand = new Random();
        int x_size = rand.nextInt(borderWidth);
        int y_size = rand.nextInt(borderHeight);
        Location[] L = new Location[x_size*y_size];
        int k =0;
        for(int i = borderWidth - x_size; i < borderWidth; i++)
        {
            for(int j = 0; j < y_size; j++)
            {
                L[k] = new Location(i, j);
                k++;
            }
        }
        return L;
    }

    public Location[] buildBorder(){
        Location[] northBorder = createHorizontalBorder(this.width, -1);
        Location[] southBorder = createHorizontalBorder(this.width, this.height);
        Location[] eastBorder = createVerticalBorder(this.height, this.width);
        Location[] westBorder = createVerticalBorder(this.height, -1);
        Location[] verticalBorder = concatArray(eastBorder, westBorder);
        Location[] horizontalBorder = concatArray(northBorder, southBorder);
        return concatArray(verticalBorder, horizontalBorder);
    }

    public Location[] createVerticalBorder(int n, int position)
    {
        Location[] border = new Location[n];
        for(int i = 0; i < n; i++)
        {
            border[i] = new Location(position, i);
        }
        return border;
    }

    public Location[] createHorizontalBorder(int n, int position)
    {
        Location[] border = new Location[n];
        for(int i = 0; i < n; i++)
        {
            border[i] = new Location(i, position);
        }
        return border;
    }

    public Location[] concatArray(Location[] j, Location[] k)
    {
        int n = j.length +k.length;
        Location[] concatArray = new Location[n];
        for(int i = 0; i < n; i++)
        {
            if(i < j.length)
            {
                concatArray[i] = j[i];
            } else
            {
                concatArray[i] = k[i - j.length];
            }
        }
        return concatArray;
    }
}
