package ca.yiyao.countingrooms;

import java.util.logging.Handler;

/**
 * Created by user on 6/27/17.
 */
public class Counter
{
    private int counter;


    public Counter()
    {
        this.counter = 0;
    }

    public void northCounter()
    {
        this.counter = this.counter + 1;
    }

    public void southCounter()
    {
        this.counter = this.counter + 1;
    }

    public void eastCounter()
    {
        this.counter = this.counter + 1;
    }

    public void westCounter()
    {

        this.counter = this.counter + 1;

    }


    public String getCounter()
    {
        return String.format("%s", this.counter);
    }
}


