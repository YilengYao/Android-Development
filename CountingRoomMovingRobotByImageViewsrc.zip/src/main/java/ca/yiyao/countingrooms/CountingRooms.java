package ca.yiyao.countingrooms;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.PrintStream;
import java.util.Scanner;

public class CountingRooms extends AppCompatActivity
{
    private Counter roomCounter;
    public Location robot;private CreateMap map;
    private Location[] forbidden;
    int layoutSize;
    public ImageView robot_image;
    private int room_Size, room_Margin, x_Correction;
    Vibrator vibrator;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counting_rooms);
        this.roomCounter = new Counter();
        this.robot = new Location();
        this.map = new CreateMap();
        this.forbidden = this.map.getMap();
        this.robot_image = (ImageView) findViewById(R.id.android_image);
        vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

    }
    protected void onStart() {
        super.onStart();
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        if(linearLayout.getWidth() > 0 || linearLayout.getHeight() > 0){
            drawGrid();
        }
    }
    public void restartGame(View view){
        this.roomCounter = new Counter();
        this.robot = new Location();
        this.map = new CreateMap();
        this.forbidden = this.map.getMap();
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout);
        if(linearLayout.getWidth() > 0 || linearLayout.getHeight() > 0){
            drawGrid();
        }
    }
    public void drawGrid(){
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.linearLayout);

        //this gets the width of linear layout from view
        this.layoutSize = linearLayout.getWidth();
        //after getting the width from view, we set the height of the LinearLayout equal to width
        //but since the proporty is set to wrap content, it will shrink to wrap our grid Reference to Will X.
        linearLayout.getLayoutParams().height = layoutSize;

        DrawMap grid = new DrawMap(this.map.height, this.map.width, this.layoutSize, this.map.blockedRooms);

        linearLayout.setBackground(grid.mapGrid);
        this.robot_image.setImageDrawable(getResources().getDrawable(R.mipmap.ic_launcher));
        room_Size = grid.roomSize;
        room_Margin = grid.margin;
        x_Correction = grid.x_correction;
        this.robot_image.getLayoutParams().height = room_Size - 2*room_Margin;
        this.robot_image.getLayoutParams().width = room_Size - 2*room_Margin;
        this.robot_image.setX(this.robot.getX()*grid.roomSize + room_Margin + x_Correction);
        this.robot_image.setY(this.robot.getY()*grid.roomSize + room_Margin);


    }
    //private Location[] forbidden = this.map.getMap();
//private Location[] forbidden = new Location[0];

    public void northClicked(View view)
    {
        if(this.robot.canGoNorth(this.forbidden))
        {
            this.roomCounter.northCounter();
            this.robot.goNorth();
        } else {
            vibrator.vibrate(200);
        }
        this.returnCount();
        this.changeColor();
        this.robot_image.setX(this.robot.getX()*room_Size + room_Margin + x_Correction);
        this.robot_image.setY(this.robot.getY()*room_Size + room_Margin);
    }

    public void southClicked(View view)
    {
        if(this.robot.canGoSouth(this.forbidden))
        {
            this.roomCounter.southCounter();
            this.robot.goSouth();
        } else {
            vibrator.vibrate(200);
        }
        this.returnCount();
        this.changeColor();
        this.robot_image.setX(this.robot.getX()*room_Size + room_Margin + x_Correction);
        this.robot_image.setY(this.robot.getY()*room_Size + room_Margin);
    }

    public void eastClicked(View view)
    {
        if(robot.canGoEast(this.forbidden))
        {
            this.roomCounter.eastCounter();
            this.robot.goEast();
        } else {
            vibrator.vibrate(200);
        }
        this.returnCount();
        this.changeColor();
        this.robot_image.setX(this.robot.getX()*room_Size + room_Margin + x_Correction);
        this.robot_image.setY(this.robot.getY()*room_Size + room_Margin);
    }

    public void westClicked(View view)
    {
        if(robot.canGoWest(this.forbidden))
        {
            this.roomCounter.westCounter();
            this.robot.goWest();
        } else {
            vibrator.vibrate(200);
        }
        this.returnCount();
        this.changeColor();
        this.robot_image.setX(this.robot.getX()*room_Size + room_Margin + x_Correction);
        this.robot_image.setY(this.robot.getY()*room_Size + room_Margin);
    }

    public void returnCount()
    {
        String answer = this.robot.toString();
        View clickCounterView = findViewById(R.id.clickCounter);
        TextView clickCounterText = (TextView) clickCounterView;
        clickCounterText.setText(answer);
    }

    public void changeColor()
    {
        TextView northButton = (TextView) findViewById(R.id.northButton);
        TextView southButton = (TextView) findViewById(R.id.southButton);
        TextView eastButton = (TextView) findViewById(R.id.eastButton);
        TextView westButton = (TextView) findViewById(R.id.westButton);

        if(this.robot.canGoNorth(this.forbidden))
        {
            northButton.setBackgroundColor(Color.GREEN);
        } else {
            northButton.setBackgroundColor(Color.RED);
        }

        if(this.robot.canGoSouth(this.forbidden))
        {
            southButton.setBackgroundColor(Color.GREEN);
        } else {
            southButton.setBackgroundColor(Color.RED);
        }

        if(this.robot.canGoEast(this.forbidden))
        {
            eastButton.setBackgroundColor(Color.GREEN);
        } else {
            eastButton.setBackgroundColor(Color.RED);
        }

        if(this.robot.canGoWest(this.forbidden))
        {
            westButton.setBackgroundColor(Color.GREEN);
        } else {
            westButton.setBackgroundColor(Color.RED);
        }

    }


}
