package com.example.yi.jumblefootprintreference;

/**
 * Created by Yi on 2017-07-25.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * The dictionary, which is the model of this app.
 *
 * @author Franck van Breugel
 */
public class Dictionary
{
    public static ArrayList<String> dictionary;
    static Map<Integer , LinkedList<String>> reference = new HashMap<Integer, LinkedList<String>>();
    int counter = 0;
    /**
     * Initializes this dictionary from the given file.  Each line of the file contains a
     * single word.
     *
     * @param file file containing the words of this dictionary.
     */
    public Dictionary(File file)
    {
        dictionary = new ArrayList<>();

        try
        {
            Scanner input = new Scanner(file);

            while (input.hasNextLine())
            {
                String word = input.nextLine();
                dictionary.add(word);
            }
            input.close();
        }
        catch (FileNotFoundException e)
        {
            // do nothing
        }
        createReference();
    }

    public void createReference()
    {
        for (String string: dictionary)
        {
           // HashMap <Character, Integer> dictionaryFootPrint = getFootprint(string.toLowerCase());
            int dictionarySumOfChar = getSumOfChar(string);
            if(!reference.containsKey(dictionarySumOfChar)){
                LinkedList<String> words = new LinkedList<>();
                words.addFirst(string);
                reference.put(dictionarySumOfChar,words);
            } else {
                LinkedList words = reference.get(dictionarySumOfChar);
                words.add(string);
                reference.put(dictionarySumOfChar,words);
            }
        }
    }


    /**
     * Returns the list of words that are unscramblings of the given word.
     *
     * @param word word to be unscrambled.
     * @return list of words that are unscramblings of the given word.
     */
    public List<String> getUnscramblings(String word)
    {
        ArrayList<String> resultList = new ArrayList<>();

        Map <Character, Integer> wordFootPrint;
        int wordSumOfChar = getSumOfChar(word);
        LinkedList<String> potential_answers = reference.get(wordSumOfChar);
        for (String answer: potential_answers) {
            wordFootPrint = getFootprint(word.toLowerCase());
            Map <Character, Integer> answerFootPrint = getFootprint(answer.toLowerCase());
            if(wordFootPrint.equals(answerFootPrint)){
                resultList.add(answer);
            }
        }
        return resultList;
    }

    public static HashMap<Character, Integer> getFootprint(String word){
        HashMap<Character, Integer> footprint = new HashMap<Character, Integer>();
        for (int i = 0; i < word.length(); i++){
            if(footprint.containsKey(word.charAt(i))){
                Integer j = footprint.get(word.charAt(i)) + 1;
                footprint.put(word.charAt(i),j);
            } else {
                footprint.put(word.charAt(i), 1);
            }
        }
        return footprint;
    }

    public int getSumOfChar(String word) {
        int sumOfChar = 0;
        for (int j = 0; j < word.length(); j++) {
            if ((word.charAt(j) >= 'A') && (word.charAt(j) <= 'Z')) {
                sumOfChar = sumOfChar + word.charAt(j) + 32;
            } else {
                sumOfChar = sumOfChar + word.charAt(j);
            }
        }
        return sumOfChar;
    }
}
