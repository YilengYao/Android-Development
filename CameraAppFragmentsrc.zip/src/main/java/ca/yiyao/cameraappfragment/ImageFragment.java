package ca.yiyao.cameraappfragment;


import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;

import ca.yiyao.cameraappfragment.MainActivity;
import ca.yiyao.cameraappfragment.R;

/**
 *  this creates the frament on which the picture is displayed
 */
public class ImageFragment extends Fragment {

    Button start;
    ImageView image;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_image, container, false);
        final MainActivity mainActivity = (MainActivity) getActivity();
        start = (Button) view.findViewById(R.id.start);

        //calls activate in the main activity which invokes the camera
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.activate();

            }
        });
        return view;
    }

    // this method pulls the bitmap from the main activity and display the bitmap as a photo on the image fragment
    public void setView()
    {
        final MainActivity mainActivity = (MainActivity) getActivity();
        // set photo as image
        image = (ImageView) getView().findViewById(R.id.image);
        image.setImageBitmap(mainActivity.getBitmap());
    }

    //sets the visibility of the Start button gone after the the picture has been taken
    public void setStartButtonGone(){
        start.setVisibility(View.GONE);
        image.setVisibility(View.VISIBLE);
    }

    //invoked from operation fragment, makes the startbutton reappear and image dissapear so we can
    //take another photo
    public void restart(){
        start.setVisibility(View.VISIBLE);
        image.setVisibility(View.GONE);
    }
}