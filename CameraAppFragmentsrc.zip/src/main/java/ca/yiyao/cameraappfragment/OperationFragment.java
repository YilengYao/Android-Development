package ca.yiyao.cameraappfragment;

import android.os.Bundle;
import android.support.annotation.IdRes;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * this frament contains all the button that we use to alter the image on the image fragment
 * the reason why is because I want to have all the button on a separate screen so I have to picture
 * on the whole screen maximizing the viewing area of the picture
 */
public class OperationFragment extends Fragment {
    Button reflectX, lower_resolution, reflectY, rotate_angle, rotate_ninety, restart;
    EditText resolution_number_text_view, angle_text_view;
    String resolution_string, angle_string;
    int resolution_number, angle_number;
    RelativeLayout operation_fragment;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_operation, container, false);
        final MainActivity mainActivity = (MainActivity) getActivity();
        reflectX = (Button) view.findViewById(R.id.reflectY);
        reflectY = (Button) view.findViewById(R.id.reflectX);
        lower_resolution = (Button) view.findViewById(R.id.lower_resolution);
        rotate_angle = (Button) view.findViewById(R.id.rotate_angle);
        rotate_ninety = (Button) view.findViewById(R.id.rotate_ninety);
        restart = (Button) view.findViewById(R.id.restart);
        resolution_number_text_view = (EditText) view.findViewById(R.id.resolution_number);
        angle_text_view = (EditText) view.findViewById(R.id.angle_number);
        operation_fragment = (RelativeLayout) view.findViewById(R.id.operation_fragment);

        //this lowers resolution of the picture
        lower_resolution.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                resolution_string = (resolution_number_text_view).getText().toString();
                //validates that input is not an empty string
                if (resolution_string.equals(""))
                {
                    Toast.makeText(getContext(), "Please enter a number", Toast.LENGTH_SHORT).show();
                } else {
                    resolution_number = Integer.parseInt(resolution_string);
                    //validates that input is not zero or less than one because we can only decrease
                    //resolution not increase it
                    if (resolution_number >= 1)
                    {
                        mainActivity.setLowerResolution(resolution_number);
                    } else
                    {
                        Toast.makeText(getContext(), "Please enter number greater than or equal to 1", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        //rotates the picture according to angle secified by the user
        rotate_angle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //validate that user does not enter empty string
                angle_string = (angle_text_view).getText().toString();
                if (!angle_string.equals(""))
                {
                    angle_number = Integer.parseInt(angle_string);
                    mainActivity.setAngleRotation(angle_number);
                } else {
                    Toast.makeText(getContext(), "Please enter a number", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // reflect along x axis
        reflectX.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.setReflectY();
            }
        });

        //reflect along y axis
        reflectY.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.setReflectX();
            }
        });

        //rotate picture at 90 degrees
        rotate_ninety.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mainActivity.setRotationNinety();
            }
        });

        /**allows us to take another picture,
        * this is a fragment to fragment communication
        *buttonClick on the Operations fragment, calls the main activity, then calls the padapter
        *which is in the main activity, then calls the image fragment Which is in the padapter,
         * which invokes the restart method in the image fragment which hides the picture and
         * makes the start button reappear in the image fragment
         */
        restart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //this calls
                mainActivity.restart();
            }
        });



        return view;
    }




}
