package ca.yiyao.cameraappfragment;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

/**
 * Created by user on 7/17/17.
 * This handles the image fragment and operations fragment, displaying one of the 2 fragments
 * depending on which direction we swipe
 */
public class PageAdapter extends FragmentPagerAdapter
{
    Boolean show_operation_fragment = false;
    ImageFragment imageFragment;
    OperationFragment operationFragment;
    //initializing the fragment
    public PageAdapter(FragmentManager fm) {
        super(fm);
        imageFragment = new ImageFragment();
        operationFragment = new OperationFragment();
    }

    //this handles which fragment is displayed depend on which direction we swipe the phone
    @Override
    public Fragment getItem(int arg0)
    {
        if (show_operation_fragment)
        {
            switch (arg0)
            {
                case 0:
                    return imageFragment;
                case 1:
                    return operationFragment;
                default:
                    break;
            }
            return null;
        } else{
            switch (arg0)
            {
                case 0:
                    return imageFragment;
                default:
                    break;
            }
            return null;
        }
    }

    @Override
    public int getCount() {
        if (show_operation_fragment)
        {
            return 2;
        } else {
            return 1;
        }
    }

    public void to_show_operation_fragment(){
        this.show_operation_fragment = true;
    }

    public void not_show_operation_fragment(){
        this.show_operation_fragment = false;
    }


}
