package ca.yiyao.cameraappfragment;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.os.Bundle;
import java.io.File;
import java.io.IOException;

public class MainActivity extends FragmentActivity
{
    // The ViewPager is where the the fragments is displayed on the main activity
    ViewPager viewpager;
    private static final String PATH = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES) + "/temp/";
    Model model_image;
    Bitmap bitmap;

    /** The PageAdapter handles the fragments it determines which fragment is displayed when we swipe the screen
     *  and allows us to access methods in the fragment using mainActivity.padapter.fragment.method();
     */
    PageAdapter padapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        viewpager = (ViewPager) findViewById(R.id.pager);
        padapter = new PageAdapter(getSupportFragmentManager());
        viewpager.setAdapter(padapter);

    }

    //invoke the camera when start is pressed
    public void activate(){
        // create file to store photo
        String path = PATH + "sample.jpg";
        File file = new File(path);
        try
        {
            file.createNewFile();
        }
        catch (IOException e)
        {
            // do nothing
        }

        // convert file to uri
        Uri uri = Uri.fromFile(file);
        // start camera
        Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        this.startActivityForResult(cameraIntent, 0);

    }

    // create the model, and passes the picture into the model, displays the picture on screen
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        // path to the photo
        String path = PATH + "sample.jpg";
        // decode the photo as a bitmap
        bitmap = BitmapFactory.decodeFile(path);

        // create model
        this.model_image = new Model(bitmap);

        //this shows the operation fragment
        padapter.to_show_operation_fragment();
        viewpager.setAdapter(padapter);

        /**access the setView method in image fragment through the PageAdapter
         * setView grabs bitmap from main activity using the getBitmap() method on the main activity
         */
        padapter.imageFragment.setView();
        //hides the start button
        padapter.imageFragment.setStartButtonGone();


    }

    /**
     * @param resolution_number
     * It is called from the operation fragment which passes a number, which invoked he lower resolution
     * method in the model which lowers the resolution of the picture by the factor of the number
     */
    public void setLowerResolution(int resolution_number){
        // update the model
        this.model_image.lowerResolution(resolution_number);
        this.bitmap = model_image.getBitmap();
        // passes he bimap image to the image fragment
        padapter.imageFragment.setView();
    }

    /**
     * @param angle_number
     * Called from the operation fragment, which rotates the picture by the specified of the angle_number
     */
    public void setAngleRotation(int angle_number){
        // update the model
        this.model_image.angleRotation(angle_number);
        this.bitmap = model_image.getBitmap();
        // passes he bimap image to the image fragment
        padapter.imageFragment.setView();
    }

    //reflect along y axis
    public void setReflectY(){
        // update the model
        this.model_image.reflectY();
        this.bitmap = model_image.getBitmap();
        // passes he bimap image to the image fragment
        padapter.imageFragment.setView();
    }

    //reflect along x axis
    public void setReflectX(){
        // update the model
        this.model_image.reflectX();
        this.bitmap = model_image.getBitmap();
        // passes he bimap image to the image fragment
        padapter.imageFragment.setView();
    }

    //rotate by 90 degrees
    public void setRotationNinety(){
        // update the model
        this.model_image.rotateNinty();
        this.bitmap = model_image.getBitmap();
        // passes he bimap image to the image fragment
        padapter.imageFragment.setView();
    }

    //return the bitmap stored in the main activity
    public Bitmap getBitmap(){
        return this.bitmap;
    }

    public void restart(){
        padapter.imageFragment.restart();
        //this hides the operation fragment
        padapter.not_show_operation_fragment();
        viewpager.setAdapter(padapter);
    }
}
