package ca.yiyao.cameraappfragment;

import android.graphics.Bitmap;

/**
 * Created by user on 7/18/17.
 */
public class Model
{
    private Bitmap bitmap, altered_resolution_bitmap, shown_bitmap;

    /**
     * Initializes this model with the given bitmap.
     *
     * @param bitmap bitmap of this model.
     */
    public Model(Bitmap bitmap)
    {
        this.bitmap = bitmap;
        altered_resolution_bitmap = Bitmap.createBitmap(this.bitmap);
        this.shown_bitmap = Bitmap.createBitmap(this.bitmap);
    }

    /**
     * Returns the bitmap of this model.
     *
     * @return bitmap of this model.
     */
    public Bitmap getBitmap()
    {
        return this.shown_bitmap;
    }

    /**
     * Returns altered_resolution_bitmap which is a bitmap with lower resolution that is specified by the user
     * @param resolution_number
     */
    public void lowerResolution(int resolution_number)
    {
        final int WIDTH = this.bitmap.getWidth();
        final int HEIGHT = this.bitmap.getHeight();
        Bitmap lower_resolution = Bitmap.createBitmap(WIDTH/resolution_number +1, HEIGHT/resolution_number +1, this.bitmap.getConfig());

        for (int x = 0; x < WIDTH; x = x + resolution_number)
        {
            for (int y = 0; y < HEIGHT; y = y + resolution_number)
            {
                int color = this.bitmap.getPixel(x, y);
                lower_resolution.setPixel(x/resolution_number, y/resolution_number, color);
            }
        }
        this.altered_resolution_bitmap = Bitmap.createBitmap(lower_resolution);
        this.shown_bitmap = this.altered_resolution_bitmap;
    }

    /**
     * Reflects the bitmap of this model along the y-axis.
     */
    public void reflectY()
    {
        final int WIDTH = this.shown_bitmap.getWidth();
        final int HEIGHT = this.shown_bitmap.getHeight();
        Bitmap reflection = Bitmap.createBitmap(WIDTH, HEIGHT, this.bitmap.getConfig());

        /**
         for (int x = 0; x < WIDTH; x++)
         {
         for (int y = 0; y < HEIGHT; y++)
         {
         int color = this.bitmap.getPixel(x, y);
         reflection.setPixel(WIDTH - 1 -x, y, color);
         }
         }
         */

        //This algorithm is faster than the previous algorithm because it runs 1 loop instead of nested loop
        final int MAX = WIDTH*HEIGHT;
        for (int k = 0; k < MAX; k++){
            int x = k%WIDTH;
            int y = k/WIDTH;
            int color = this.shown_bitmap.getPixel(x, y);
            reflection.setPixel(WIDTH - 1 -x, y, color);
        }
        this.shown_bitmap = reflection;
    }

    public void reflectX()
    {
        final int WIDTH = this.shown_bitmap.getWidth();
        final int HEIGHT = this.shown_bitmap.getHeight();
        Bitmap reflection = Bitmap.createBitmap(WIDTH, HEIGHT, this.bitmap.getConfig());
        final int MAX = WIDTH*HEIGHT;
        for (int k = 0; k < MAX; k++){
            int x = k%WIDTH;
            int y = k/WIDTH;
            int color = this.shown_bitmap.getPixel(x, y);
            reflection.setPixel(x,HEIGHT -1- y, color);

        }
        this.shown_bitmap = reflection;
    }

    /**
     * Rotates the picture at an angle specified by the user
     * @param angle
     */
    public void angleRotation(int angle)
    {
        final int WIDTH = this.altered_resolution_bitmap.getWidth();
        final int HEIGHT = this.altered_resolution_bitmap.getHeight();

        //the center of the circle
        final int Xo = WIDTH/2;
        final int Yo = HEIGHT/2;

        //converting the angle in degree to radion because the Math trigonomic methods has radians as parameters
        final double PHETA = Math.PI*angle/180;

        /**when we rotate the picture some of its corners go into quadrants of the cartian plane that has negative coordinates
         * the following translate the picture back into a frame of reference where all its coordinates are positive
         * because the bitmap is only defined with positive coordinates
         * we use the corners as our anchor points because they are the point that will give the most negative values
         */
        int X3= (int) Math.round(Math.cos(PHETA)*(0-Xo)-Math.sin(PHETA)*(0-Yo))+Xo;
        int Y3 = (int) Math.round(Math.sin(PHETA)*(0-Xo)+Math.cos(PHETA)*(0-Yo))+Yo;
        int X4= (int) Math.round(Math.cos(PHETA)*(0-Xo)-Math.sin(PHETA)*(HEIGHT-1-Yo))+Xo;
        int Y4 = (int) Math.round(Math.sin(PHETA)*(0-Xo)+Math.cos(PHETA)*(HEIGHT-1-Yo))+Yo;
        int X5= (int) Math.round(Math.cos(PHETA)*(WIDTH-1-Xo)-Math.sin(PHETA)*(HEIGHT-1-Yo))+Xo;
        int Y5 = (int) Math.round(Math.sin(PHETA)*(WIDTH-1-Xo)+Math.cos(PHETA)*(HEIGHT-1-Yo))+Yo;
        int X6= (int) Math.round(Math.cos(PHETA)*(WIDTH-1-Xo)-Math.sin(PHETA)*(0-Yo))+Xo;
        int Y6 = (int) Math.round(Math.sin(PHETA)*(WIDTH-1-Xo)+Math.cos(PHETA)*(0-Yo))+Yo;
        //the minimum of all the nagative value is what we use to translate the picture so all its coordinates are positive
        int minX= min(X3,X4,X5,X6);
        int minY= min(Y3,Y4,Y5,Y6);

        /**
         * the following sets the width and height of our new bitmap, since the corner points has the most extreme coordinates
         *  of any x and y coordinates we use it as an anchor to set the width and height of our bitmal
         */
        int cornerX1 = (int) Math.round(Math.cos(PHETA)*(0-Xo)-Math.sin(PHETA)*(0-Yo)+Xo)+Math.abs(minX);
        int cornerY1 = (int) Math.round(Math.sin(PHETA)*(0-Xo)+Math.cos(PHETA)*(0-Yo)+Yo)+Math.abs(minY);
        int cornerX2 = (int) Math.round(Math.cos(PHETA)*(WIDTH-Xo)-Math.sin(PHETA)*(0-Yo)+Xo)+Math.abs(minX);
        int cornerY2 = (int) Math.round(Math.sin(PHETA)*(WIDTH-Xo)+Math.cos(PHETA)*(0-Yo)+Yo)+Math.abs(minY);
        int cornerX3 = (int) Math.round(Math.cos(PHETA)*(WIDTH-Xo)-Math.sin(PHETA)*(HEIGHT-Yo)+Xo)+Math.abs(minX);
        int cornerY3 = (int) Math.round(Math.sin(PHETA)*(WIDTH-Xo)+Math.cos(PHETA)*(HEIGHT-Yo)+Yo)+Math.abs(minY);
        int cornerX4 = (int) Math.round(Math.cos(PHETA)*(0-Xo)-Math.sin(PHETA)*(HEIGHT-Yo)+Xo)+Math.abs(minX);
        int cornerY4 = (int) Math.round(Math.sin(PHETA)*(0-Xo)+Math.cos(PHETA)*(HEIGHT-Yo)+Yo)+Math.abs(minY);
        final int MAXWIDTH = max(cornerX1, cornerX2, cornerX3, cornerX4);
        final int MAXHEIGHT = max(cornerY1, cornerY2, cornerY3, cornerY4);

        Bitmap reflection = Bitmap.createBitmap(MAXWIDTH+1, MAXHEIGHT+1, this.bitmap.getConfig());
        //algorithm to rotate the pixels
        final int MAX = WIDTH*HEIGHT;
        for (int k = 0; k < MAX; k++){
            int x = k%WIDTH;
            int y = k/WIDTH;
            int color = this.altered_resolution_bitmap.getPixel(x, y);
            int X2= (int) Math.round(Math.cos(PHETA)*(x-Xo)-Math.sin(PHETA)*(y-Yo)+Xo)+Math.abs(minX);
            int Y2 = (int) Math.round(Math.sin(PHETA)*(x-Xo)+Math.cos(PHETA)*(y-Yo)+Yo)+Math.abs(minY);
            reflection.setPixel(X2,Y2, color);
        }
        this.shown_bitmap = reflection;
    }

    //rotate bitmap 90 degrees
    public void rotateNinty()
    {
        final int WIDTH = this.altered_resolution_bitmap.getWidth();
        final int HEIGHT = this.altered_resolution_bitmap.getHeight();
        Bitmap reflection = Bitmap.createBitmap(HEIGHT, WIDTH, this.bitmap.getConfig());
        final int MAX = WIDTH*HEIGHT;
        for (int k = 0; k < MAX; k++){
            int x = k%WIDTH;
            int y = k/WIDTH;
            int color = this.altered_resolution_bitmap.getPixel(x, y);
            reflection.setPixel(HEIGHT - 1 -y, x, color);
        }
        this.shown_bitmap = reflection;
    }

    //method to return maximum of 4 doubles
    public static double max(double a, double b, double c, double d) {
        double max = a;
        if (b > max)
            max = b;
        if (c > max)
            max = c;
        if (d > max)
            max = d;
        return max;
    }

    //method to return minimum of 4 ints
    public static int min(int a, int b, int c, int d) {
        int min = a;
        if (b < min)
            min = b;
        if (c < min)
            min = c;
        if (d < min)
            min = d;
        return min;
    }

    //method to return maximum of 4 ints
    public static int max(int a, int b, int c, int d) {
        int max = a;
        if (b > max)
            max = b;
        if (c > max)
            max = c;
        if (d > max)
            max = d;
        return max;
    }
}
